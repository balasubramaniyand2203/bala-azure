resource "azurerm_kubernetes_cluster" "aks" {

  name                = var.aks_name
  location            = var.location
  resource_group_name = var.rg_name
  dns_prefix          = "aksdns"

  default_node_pool {

    name = "nodepool"

    vm_size = "Standard_B2s"

    node_count = 2

    enable_auto_scaling = true
    min_count = 2
    max_count = 4

    vnet_subnet_id = var.subnet_id
  }

  identity {
    type = "SystemAssigned"
  }

  network_profile {

    network_plugin = "azure"

    service_cidr = "10.2.0.0/16"

    dns_service_ip = "10.2.0.10"

    docker_bridge_cidr = "172.17.0.1/16"
  }

}

resource "azurerm_role_assignment" "acr_pull" {

  principal_id = azurerm_kubernetes_cluster.aks.kubelet_identity[0].object_id

  role_definition_name = "AcrPull"

  scope = var.acr_id
}