variable "aks_name" {}
variable "location" {}
variable "rg_name" {}

variable "subnet_id" {}

variable "acr_id" {}