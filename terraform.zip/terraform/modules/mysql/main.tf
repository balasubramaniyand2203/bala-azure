resource "azurerm_mysql_flexible_server" "mysql" {

  name                = var.mysql_name
  location            = var.location
  resource_group_name = var.rg_name

  administrator_login    = var.admin_user
  administrator_password = var.admin_password

  sku_name = "B_Standard_B1ms"

  version = "8.0"

  storage {
    size_gb = 20
  }

}