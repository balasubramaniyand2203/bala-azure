variable "mysql_name" {}
variable "rg_name" {}
variable "location" {}

variable "admin_user" {}
variable "admin_password" {
  sensitive = true
}